using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoints : MonoBehaviour
{
    public Transform[] waypoints;
}
/*
public class Path
{
    public Transform[] waypoints;
}
*/